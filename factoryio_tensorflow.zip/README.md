# Manutenção Preditiva de Motores Industriais com IA – Versão Industrial

Projeto de IA para prever falhas em motores industriais usando dados de sensores.
Integração com Factory I/O, SCADA/MES e SAP PM para portfólio profissional.
